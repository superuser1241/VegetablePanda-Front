import React from 'react';

const UpdateForm = () => {
    return (
        <div>
            
        </div>
    );
};

export default UpdateForm;